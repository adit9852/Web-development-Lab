## DBMS Lab Task README File

#### Name: Aditya Kumar
#### Branch: IT
#### Roll no.: 22IT3002

### Attached to the folder is a PDF and word file containing all the Tasks informations.

## Task 1
The theory is completely written in the PDF/word file.

## Task 2
The task was supposed to be done with SQL. Attached to the folder We have an SQL script which can be run on any sql compiler/ software one such named MySQL on which I created this.

### How to run the script
Simply open the script anywhere like in MySQL or VS Code and execute the script either completely or portion wise to see the execution.

## Task 3
In this task we were supposed to write python code. I have attached two python codes showing two different approaches for the problem given.
You can run the code in any python supporting compiler or software example VS Code, pycharm, Jupyter notebook, Google Colab etc.

### How to run the code
Open the code anywhere as mentioned above and execute it with Execute button or key combination (Ctrl+Alt+N)(in VS Code).
#### If you want to run the code through terminal follow the following instructions:
 - Move to the directory of your python script if you are not already by cd path/to/my_python_scripts for instance.
 - Now run the script by python filename.py