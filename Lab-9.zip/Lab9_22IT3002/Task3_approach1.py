from collections import defaultdict

class PrecedenceGraph:
	def __init__(self, V):
		self.V = V
		self.adj = defaultdict(list)
		self.serialSchedule = []

	def addEdge(self, v, w):
		self.adj[v].append(w)

	def computeIndegree(self, indegree):
		for i in range(1, self.V):
			for node in self.adj[i]:
				indegree[node] += 1

	def findZeroIndegree(self, indegree, visited):
		for i in range(1, self.V):
			if not visited[i] and indegree[i] == 0:
				visited[i] = True
				return i
		return -1

	def topologicalSort(self):
		visited = [False for i in range(self.V)]

		indegree = [0 for i in range(self.V)]

		self.computeIndegree(indegree)

		node = self.findZeroIndegree(indegree, visited)
		nodeAvailable = False
		if node != -1:
			nodeAvailable = True

		while nodeAvailable:
			self.serialSchedule.append(node)
			for next_node in self.adj[node]:
				indegree[next_node] -= 1

			node = self.findZeroIndegree(indegree, visited)

			if node == -1:
				nodeAvailable = False

	def printSchedule(self):
		print("Equivalent Serial Schedule is: ", end="")
		for i in self.serialSchedule:
			print("T{} ".format(i), end="")

if __name__ == "__main__":
	graph = PrecedenceGraph(4)
	graph.addEdge(2, 1)
	graph.addEdge(2, 3)
	graph.addEdge(3, 1)

	graph.topologicalSort()

	graph.printSchedule()