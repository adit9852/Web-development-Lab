CREATE DATABASE Transactions_assign;
USE Transactions_assign;

CREATE TABLE accounts (
    account_number VARCHAR(10),
    balance INT
);

INSERT INTO accounts (account_number, balance) VALUES ('A29', 2000), ('B29', 4000);

-- Set isolation level
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

-- Transaction 1
START TRANSACTION;
UPDATE accounts SET balance = balance - 300 WHERE account_number = 'A29';
COMMIT;


-- transaction2
START TRANSACTION;
UPDATE accounts SET balance = balance + 100 WHERE account_number = 'B29';
COMMIT;