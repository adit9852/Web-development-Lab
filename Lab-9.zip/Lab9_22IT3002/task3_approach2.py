import re

def parse_schedule(schedule):
    """
    Parses the input schedule and returns a list of operations.
    """
    operations = []
    for s in schedule:
        match = re.match(r"(?P<tid>\w+)\((?P<op>W|R)\+(?P<var>\w+)\)", s)
        if match:
            operations.append(match.groupdict())
    return operations

def build_precedence_graph(operations):
    """
    Builds a precedence graph from the input operations.
    """
    graph = {}
    for op in operations:
        tid = op["tid"]
        if tid not in graph:
            graph[tid] = []
        for other_op in operations:
            if op != other_op and (
                (op["op"] == "W" and other_op["op"] == "R" and other_op["var"] == op["var"]) or
                (op["op"] == "W" and other_op["op"] == "W" and other_op["var"] == op["var"]) or
                (op["op"] == "R" and other_op["op"] == "W" and other_op["var"] == op["var"] and op["tid"] != other_op["tid"])
            ):
                other_tid = other_op["tid"]
                if other_tid not in graph[tid]:
                    graph[tid].append(other_tid)
    return graph

def is_acyclic(graph):
    """
    Checks if the precedence graph is acyclic.
    """
    visited = set()
    stack = []

    def visit(node):
        if node in visited:
            return False
        if node in stack:
            return True
        visited.add(node)
        stack.append(node)
        for neighbor in graph.get(node, []):
            if not visit(neighbor):
                return False
        stack.pop()
        return True

    for node in graph:
        if not visit(node):
            return False
    return True

def get_serial_schedule(operations):
    """
    Returns a serial schedule if the input schedule is conflict serializable.
    """
    graph = build_precedence_graph(operations)
    if is_acyclic(graph):
        sorted_nodes = sorted(graph, key=lambda x: sorted(graph[x]))
        return [op["tid"] for op in operations if op["tid"] in sorted_nodes]
    return None

if __name__ == "__main__":
    schedule = ["R1(A)", "W1(A)", "R2(B)", "W2(B)", "R3(A)", "W3(A)", "R3(B)", "W3(B)"]
    operations = parse_schedule(schedule)
    graph = build_precedence_graph(operations)
    if is_acyclic(graph):
        serial_schedule = get_serial_schedule(operations)
        if serial_schedule:
            print("Conflict Serializable: Yes")
            print("Equivalent Serial Schedule: ", " ".join(serial_schedule))
        else:
            print("Conflict Serializable: Yes")
            print("Equivalent Serial Schedule: None")
    else:
        print("Conflict Serializable: No")